function y = f1(x)
    global A m
    [~,s] = sort(x);
    x = s(1:m);
    y = 0;
    for i = 1:m
        y = y - A(i,x(i));
    end
end